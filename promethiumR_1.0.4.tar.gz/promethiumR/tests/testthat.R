library(testthat)
test_check("promethiumR")
